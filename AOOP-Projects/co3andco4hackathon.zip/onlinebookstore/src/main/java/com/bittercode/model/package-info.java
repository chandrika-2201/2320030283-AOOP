/**
 * 
 */
/**
 * @author harini
 *
 */
package com.bittercode.model;
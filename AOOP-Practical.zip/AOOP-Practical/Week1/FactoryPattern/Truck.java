package com.FactoryPattern;

public class Truck implements Vehicle {

	@Override
	public void drive() {
		// TODO Auto-generated method stub
		System.out.println("I am driving a truck");
	}

}

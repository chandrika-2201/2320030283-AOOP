package PL;

public class Bike implements Vehicle {
	public void requestRide() {
        System.out.println("Requesting a Bike ride!!!");
    }
}

package PL;

public class Scooter implements Vehicle {
	public void requestRide() {
        System.out.println("Requesting a Scooter ride!!!");
    }
}

package game;

public class OrcEnemy implements Enemy {
	public void attack() {
        System.out.println("Orc enemy attack!");
    }
}
